import React from 'react';
import RaisedButton from 'material-ui/RaisedButton';
import Snackbar from 'material-ui/Snackbar';
import CircularProgress from 'material-ui/CircularProgress';
import Dialog from 'material-ui/Dialog';
import MenuItem from 'material-ui/MenuItem';
import DropDownMenu from 'material-ui/DropDownMenu';
import Badge from 'material-ui/Badge';
import FlatButton from 'material-ui/FlatButton';import {connect} from 'react-redux';
import Avatar from 'material-ui/Avatar';
import {selected_menu_click,fetchsubitem,fetch_product_status} from '../actions/actions';
import List from 'material-ui/List/List';
import ListItem from 'material-ui/List/ListItem';
import {
  deepOrange300,
  purple500,
} from 'material-ui/styles/colors';


const styles={
  alreadyaddedinCart:{
    backgroundColor:'rgba(247,246,207,0.4)'
  }
}
 var ClickedSubcategoryData=null;
 var subCategoryIndexing=null
 const defaultProductQuantity=1;
class ProductList extends React.Component{

  constructor(props){
    super(props);
this.state={disabled:null,handleSnackbar:false,largeView:false,layoutType:1,dataForlargeView:null,updatePage:true,errorstatus:false};
this.handleLargeView=this.handleLargeView.bind(this);
this.handleClose=this.handleClose.bind(this);
this.handleAddProductRequest=this.handleAddProductRequest.bind(this);
this.handleChangeinDropDown=this.handleChangeinDropDown.bind(this);
}

handleChangeinDropDown(currentObject,parentId,event,key,value)
{
  console.log("lkjvlkfnvkfdnd",currentObject.childProducts[key],key,value);
      for(var i=0;i<ClickedSubcategoryData.products.length;i++)
    {       console.log(ClickedSubcategoryData.products[i].name,currentObject.childProducts[key]);
        if(ClickedSubcategoryData.products[i].id===parentId)
        {console.log(ClickedSubcategoryData.products[i].id, this.props.selectedmenuonclick[subCategoryIndexing].name);

         this.props.selectedmenuonclick[subCategoryIndexing].name.products[i].id=currentObject.childProducts[key].id;
               this.props.selectedmenuonclick[subCategoryIndexing].name.products[i].name=currentObject.childProducts[key].name;
               this.props.selectedmenuonclick[subCategoryIndexing].name.products[i].productNameTag=currentObject.childProducts[key].productNameTag;
               this.props.selectedmenuonclick[subCategoryIndexing].name.products[i].tag=currentObject.childProducts[key].tag;
               this.props.selectedmenuonclick[subCategoryIndexing].name.products[i].status=currentObject.childProducts[key].status;
               this.props.selectedmenuonclick[subCategoryIndexing].name.products[i].description=currentObject.childProducts[key].description;
               this.props.selectedmenuonclick[subCategoryIndexing].name.products[i].productPrice=currentObject.childProducts[key].productPrice;
               this.props.selectedmenuonclick[subCategoryIndexing].name.products[i].discountedPrice=currentObject.childProducts[key].discountedPrice;
               this.props.selectedmenuonclick[subCategoryIndexing].name.products[i].discountPerCent=currentObject.childProducts[key].discountPerCent;
               this.props.selectedmenuonclick[subCategoryIndexing].name.products[i].discountedAomunt=currentObject.childProducts[key].discountedAomunt;
             this.props.selectedmenuonclick[subCategoryIndexing].name.products[i].productBrand=currentObject.childProducts[key].productBrand;
              this.props.selectedmenuonclick[subCategoryIndexing].name.products[i].deliveryCharge=currentObject.childProducts[key].deliveryCharge;
              this.props.selectedmenuonclick[subCategoryIndexing].name.products[i].serchCount=currentObject.childProducts[key].serchCount;
              this.props.selectedmenuonclick[subCategoryIndexing].name.products[i].orderCount=currentObject.childProducts[key].orderCount;
              this.props.selectedmenuonclick[subCategoryIndexing].name.products[i].hitCount=currentObject.childProducts[key].hitCount;
              this.props.selectedmenuonclick[subCategoryIndexing].name.products[i].stock=currentObject.childProducts[key].stock;
              this.props.selectedmenuonclick[subCategoryIndexing].name.products[i].imgUrl=currentObject.childProducts[key].imgUrl;
              this.props.selectedmenuonclick[subCategoryIndexing].name.products[i].productQuantity=currentObject.childProducts[key].productQuantity;
              this.props.selectedmenuonclick[subCategoryIndexing].name.products[i].productUnit=currentObject.childProducts[key].productUnit;
               // //   console.log("Cdcdcd",this.props.selectedmenuonclick,this.props.lastadded,value);
               //   const checkalreadyIncart=this.state.disabled.findIndex((entry,index)=> {
               //            console.log("Fdfhdjfbdkjbf",entryId,value);
               //              if (entryId ===value)
               //                return true
               //              })
               //    console.log(checkalreadyIncart);
               //          if(checkalreadyIncart!=true)
               //          {console.log("ndjbfjd");
                      
               //           }




          }
                break;
   }
    this.setState({updatePage:true,handleSnackbar:false});
  }

handleLargeView(dataValue)
{ console.log(dataValue);
  this.setState({handleSnackbar:false,largeView:true,dataForlargeView:dataValue});
}
handleClose(){
    this.setState({handleSnackbar:false,largeView: false});
  }

handleAddProductRequest(addRequest,event)
{console.log("handleAddProductRequest",addRequest,this.props.cartDetails);
    //document.getElementById(addRequest).disabled;
    if(this.props.cartDetails[0].cart_items!=null)
    {
      const alreadyIncart=this.props.cartDetails[0].cart_items.some(entry=> {
  console.log(entry.id,addRequest);
    if (entry.id ===addRequest)
      return true
    });
if(!alreadyIncart)
{
   this.props.dispatch(fetch_product_status(addRequest,this.props.cartDetails[0].cart_id,defaultProductQuantity));
  //  document.getElementById(addRequest).disabled;
  //  document.getElementById(addRequest).style.backgroundColor = 'rgba(247,246,207,0.4)';
 //this.setState({disabled:addRequest});
}
    }
     //Harshit Please check else part
    else
    {
      this.props.dispatch(fetch_product_status(addRequest,this.props.cartDetails[0].cart_id,defaultProductQuantity));
  //    document.getElementById(addRequest).disabled;
  //  document.getElementById(addRequest).style.backgroundColor = 'rgba(247,246,207,0.4)';

    }

  
   
  }

componentWillReceiveProps(nextProps) {
console.log("fdfD",nextProps.status);
  if ((this.props.status!=nextProps.status) && nextProps.status==='N') {
    this.setState({errorstatus:true,handleSnackbar:true})
  }
    else
      { console.log("componentWillReceiveProps");
        if(nextProps.cartDetails[0].cart_items != this.props.cartDetails[0].cart_items) {
   const disabledValues= nextProps.cartDetails[0].cart_items.map(cart_item=>(cart_item.id))
console.log("disabled Value",disabledValues);
  this.setState({handleSnackbar:(this.state.disabled===disabledValues ? false:true),disabled:disabledValues,errorstatus:false});
    }
    else
    {
          this.setState({errorstatus:false,handleSnackbar:false})

    }
  }
}
componentDidMount(){
  console.log("componentDidMount ProductList",this.props.params.id)
  this.props.selectedmenuonclick===undefined ? this.props.dispatch(selected_menu_click(this.props.params.id)): null;
  // let urlReaderArray=this.props.params.id.split("/");


  // console.log("llllllllllll",urlReaderArray); 
  // if(urlReaderArray.length==1)
  // {
  //      currentSelection=urlReaderArray[0];console.log("Currrent currentSubCategory",currentSelection);this.props.dispatch(selected_menu_click(currentSelection));
 
  // }
  // else if(urlReaderArray.length==2)
  // {
  //   currentSelection=urlReaderArray[1];console.log("Currrent currentSubCategory",urlReaderArray[0]);

  //   this.props.dispatch(selected_menu_click(urlReaderArray[0]));
  // }
  // else if(urlReaderArray.length==3)
  // {
  //   currentSelection=urlReaderArray[0];
  // // this.props.dispatch(selected_menu_click(currentSelection));
  // }
  // else
  // {
  //   this.props.dispatch(selected_menu_click("Not Found"));
  // }
//  this.props.selectedmenuonclick===undefined ?  this.props.dispatch(selected_menu_click(this.props.params.id)) : "";//  this.props.dispatch(fetchsubitem(this.props.params.id));
} 
  
  
render(){
const {selectedmenuonclick,isListFetching,Listitems,selectedcategoryName,cartDetails}=this.props;{/* missing layoutType*/}
var item=[];
console.log("ppppppppppp",this.props.params.subcategoryId);
if(selectedmenuonclick!=undefined)
{for(var i=0;i<selectedmenuonclick.length;i++)
{

if(selectedmenuonclick[i].name.name===this.props.params.subcategoryId)
{ console.log("dffffdfdfff",selectedmenuonclick[i].name.name,this.props.params.productUrl);
   ClickedSubcategoryData=selectedmenuonclick[i].name;
   subCategoryIndexing=i;
 for(var element=0;element<selectedmenuonclick[i].name.products.length;element++)
{
  if(this.props.params.productUrl===undefined)
  {
  item.push(<div className="col-lg-3 col-md-4 col-xs-9 col-sm-6 productcol" key={element} style={(this.state.disabled!=null && this.state.disabled.includes(selectedmenuonclick[i].name.products[element].id)===true) ? styles.alreadyaddedinCart:null } id={selectedmenuonclick[i].name.products[element].id}>{/*<!--- Start of productcol-->*/}

         <div className="productDisplaySection">
            <img src="C:/Users/753554/Downloads/checkonly.png" className="productimage"  onClick={this.handleLargeView.bind(null,selectedmenuonclick[i].name.products[element])}  />
         </div>
         <div  className=" col-lg-8 col-md-8 col-xs-8 productNameHeader">{selectedmenuonclick[i].name.products[element].name}</div>
      
        <div  className=" col-lg-4 col-md-4 col-xs-4" style={{float:'right',padding:0,top:0}} >
          <DropDownMenu value={selectedmenuonclick[i].name.products[element].id}  underlineStyle={{margin:'-1px 0',right:'35px'}} labelStyle={{paddingLeft:0}} onChange={this.handleChangeinDropDown.bind(null,selectedmenuonclick[i].name.products[element],selectedmenuonclick[i].name.products[element].id)}>
              { selectedmenuonclick[i].name.products[element].childProducts.map((childProduct,index)=>{    
                    return ( <MenuItem key={index} value={childProduct.id}  primaryText={`${childProduct.productQuantity} ${childProduct.productUnit}`} />)

                })
              }
           </DropDownMenu>
        </div>
     <div  className=" col-lg-9 col-md-9 col-xs-9 productNameHeader">
      <div className="priceSection">
         <span className="amountafterdiscount">Rs {selectedmenuonclick[i].name.products[element].discountedPrice}</span>
         <span className="originalamount">{selectedmenuonclick[i].name.products[element].productPrice}</span>
         <span className="discountpercent">{`${selectedmenuonclick[i].name.products[element].discountPerCent}%`}</span>
         </div>
         </div>
         <RaisedButton label="BUY" buttonStyle={{background:"#de3900"}}   style={{float:'left',minWidth:85}}/>
         {(this.state.disabled!=null && this.state.disabled.includes(selectedmenuonclick[i].name.products[element].id)===true) ?
              <RaisedButton label="Add" id={selectedmenuonclick[i].name.products[element].id} disabled={true}  secondary={true} onClick={this.handleAddProductRequest.bind(null,selectedmenuonclick[i].name.products[element].id)}   style={{float:'right',minWidth:85}}/> 

:      <RaisedButton label="Add" id={selectedmenuonclick[i].name.products[element].id} disabled={false}  secondary={true} onClick={this.handleAddProductRequest.bind(null,selectedmenuonclick[i].name.products[element].id)}   style={{float:'right',minWidth:85}}/> 

       }
        
     
</div>         );

}
else if(this.props.params.productUrl!=undefined && selectedmenuonclick[i].name.products[element].name===this.props.params.productUrl)
  {
  item.push(<div className="col-lg-3 col-md-4 col-xs-9 col-sm-6 productcol" key={element} id={selectedmenuonclick[i].name.products[element].id}>{/*<!--- Start of productcol-->*/}

         <div className="productDisplaySection">
            <img src="C:/Users/753554/Downloads/checkonly.png" className="productimage"  onClick={this.handleLargeView.bind(null,selectedmenuonclick[i].name.products[element])}  />
         </div>
         <div  className=" col-lg-8 col-md-8 col-xs-8 productNameHeader">{selectedmenuonclick[i].name.products[element].name}</div>
      
        <div  className=" col-lg-4 col-md-4 col-xs-4" style={{float:'right',padding:0,top:0}} >
          <DropDownMenu value={selectedmenuonclick[i].name.products[element].id}  underlineStyle={{margin:'-1px 0',right:'35px'}} labelStyle={{paddingLeft:0}} onChange={this.handleChangeinDropDown.bind(null,selectedmenuonclick[i].name.products[element],selectedmenuonclick[i].name.products[element].id)}>
              { selectedmenuonclick[i].name.products[element].childProducts.map((childProduct,index)=>{    
                    return ( <MenuItem key={index} value={childProduct.id}  primaryText={`${childProduct.productQuantity} ${childProduct.productUnit}`} />)

                })
              }
           </DropDownMenu>
        </div>
     <div  className=" col-lg-9 col-md-9 col-xs-9 productNameHeader">
      <div className="priceSection">
         <span className="amountafterdiscount">Rs {selectedmenuonclick[i].name.products[element].discountedPrice}</span>
         <span className="originalamount">{selectedmenuonclick[i].name.products[element].productPrice}</span>
         <span className="discountpercent">{`${selectedmenuonclick[i].name.products[element].discountPerCent}%`}</span>
         </div>
         </div>
         <RaisedButton label="BUY" buttonStyle={{background:"#de3900"}}   style={{float:'left',minWidth:85}}/>
         {(this.state.disabled!=null && this.state.disabled.includes(selectedmenuonclick[i].name.products[element].id)===true) ?
              <RaisedButton label="Add" id={selectedmenuonclick[i].name.products[element].id} disabled={true}  secondary={true} onClick={this.handleAddProductRequest.bind(null,selectedmenuonclick[i].name.products[element].id)}   style={{float:'right',minWidth:85}}/> 

:      <RaisedButton label="Add" id={selectedmenuonclick[i].name.products[element].id} disabled={false}  secondary={true} onClick={this.handleAddProductRequest.bind(null,selectedmenuonclick[i].name.products[element].id)}   style={{float:'right',minWidth:85}}/> 

       }
        
     
</div>         );
break;
}

}
break;
}
 
 

}
}
else
{
item.push( <List key={1}>
<ListItem
      disabled={true}
      leftAvatar={
        <Avatar
          color={deepOrange300}
          backgroundColor={purple500}
          size={30}
        >
          A
        </Avatar>
      }
    >
      Letter Avatar with custom colors and size
    </ListItem>
</List>)
}
  return(
   <div className="col-lg-9 col-md-9 col-xs-12 col-sm-12" style={{borderLeft:'10px solid transparent'}}>
 <div className="row shopcategoriesSection">
      <div className="selectedcategorytitle">{selectedcategoryName}</div>
      </div>
    
 {/*<!-- pRODUCT lIST banner check carousel .js-->*/}   


    
    {isListFetching && <div className="row features-loader"><div className="alingCenter"><CircularProgress size={70} thickness={6} /><div className="selectedcategorytitle">Fetching Our Latest Offers</div></div></div>}
    
    {!isListFetching  && this.state.updatePage===true && <div className="row features-grid">
   { item} 

</div>
    }

{ this.state.errorstatus===true && this.state.handleSnackbar===true && <Snackbar open={this.state.handleSnackbar} message={`Something Went Wrong`} autoHideDuration={4000} />}

{ this.state.errorstatus===false && this.state.handleSnackbar===true && <Snackbar open={this.state.handleSnackbar} message={`wopiee Addedd Successfuly ${cartDetails[0].cart_items[cartDetails[0].cart_items.length-1].name}`} autoHideDuration={4000} />}

{this.state.largeView===true &&      <Dialog
          title="Large View "
      actions={<FlatButton
      label="Ok"
      primary={true}
      onTouchTap={this.handleClose}
      keyboardFocused={true}/>}
          modal={false}
          open={this.state.largeView}
          onRequestClose={this.handleClose}
         
        >
    <div className="row" style={{paddingTop:10,borderTop:'1px solid rgb(224, 224, 224)'}}>
<div className="col-xs-6 col-md-6 col-lg-6 col-sm-6" style={{height:300}}><img src="C:/Users/753554/Downloads/checkonly.png" style={{width:"100%"}}/></div>
    <div className="col-xs-6 col-md-6 col-lg-6 col-sm-6 largeViewDialog" style={{height:300}}>
    <div className="largeviewTitle">Details</div>
    <div>{this.state.dataForlargeView.description}</div>
    </div>
    </div>
        </Dialog>}
{/* End of MainContent */}

</div> 

  )
} 
  
}

const mapStateToProps=(state,ownProps)=>{
  const {fetchmenuReducer,fetchsubitemReducer}=state;
const {selectedcategoryName,selectedmenuonclick,cartDetails,status}=fetchmenuReducer;
const {isListFetching,Listitems}=fetchsubitemReducer[fetchsubitemReducer.subcategoryItem]||{isListFetching:false,Listitems:[]};
return {selectedmenuonclick,isListFetching,Listitems,selectedcategoryName,cartDetails,status};

}


export default connect(mapStateToProps)(ProductList);

