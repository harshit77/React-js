import React from 'react';

export default class NotFound extends React.Component {
	render(){
 return (<div className="col-lg-9 col-md-9 col-xs-12 col-sm-12">
 <div className="row shopcategoriesSection">
		  <div className="selectedcategorytitle">Not Found</div>
		  </div>
 </div>)		
	}
	
 }