import {SubmissionError} from 'redux-form';
import {saveUserIdAfterLogin} from './../actions/actions';



const AddressSubmit=(values,dispatch)=>{
	const addressID=values.addressID===undefined ?  null:values.addressID;
	console.log("Inside AddressSubmit ",addressID);
	return fetch('http://54.254.254.57:8080/hsahu/api/address',{
	method: 'post',mode: 'cors',credentials: 'same-origin',
	body: JSON.stringify({
		"addressID":addressID,
"firstName":values.firstName,
"lastName":values.lastName,
"address":values.address,
"emailId":values.emailId,
"mobileNumber":values.mobileNumber,
"alternateMobileNumber":values.alternateMobileNumber
	}),
	headers: new Headers({
		'Content-Type': 'application/json'
	})
}).then(response =>{
	console.log("Inside AddressSubmit ");
		if(response.status==200)
		return response.json()
		else
			throw new SubmissionError({_error:response.statusText})
        // submission was successful
      }, errors => {
        // submission was unsuccessful
      }).then((json)=>{console.log(json);

      	if(json.message==="Ok.")
      	{
      			//do nothing 
      	}
      	else
      	{
      		dispatch(saveUserIdAfterLogin(null));
      		throw new SubmissionError({_error:json.message})
      	}
      })
		;

}
export default AddressSubmit;