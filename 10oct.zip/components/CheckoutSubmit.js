import {SubmissionError} from 'redux-form';
import {saveState} from './../actions/actions';

const CheckoutSubmit=(values,dispatch,)=>{
	let date=new Date(values.checkin_date);
	console.log("dshjfsvhfvdshf", date.getDate()+"-"+(date.getMonth()+1)+"-"+date.getFullYear().toString());
	// fetch('http://www.json-generator.com/api/json/get/cpNshNSliW?indent=2').then(response =>{

	// 	return response.json()
 //        // submission was successful
 //      }, errors => {
 //        // submission was unsuccessful
 //      }).then((json)=>{console.log(json);dispatch(saveState(json))});


// return Sleep(1000).then(()=>{
// 		if(!['harshit','Vatsalya','Rishi'].includes(values.username))
// 			 throw new SubmissionError({username:"Username does not exists",_error:"! Login Failed"})
// 		else if(values.password!=="redux-form")
// 			throw new SubmissionError({password:"Wrong password",_error:"! Login Failed"})
// 		else
// 			console.log(`You Submitted \n \n ${JSON.stringify(values,null,2)}`);
// })
}
export default CheckoutSubmit;
