import React from 'react';
import Paper from 'material-ui/Paper';
import ImageEdit from 'material-ui/svg-icons/image/edit';
import ActionDelete from 'material-ui/svg-icons/action/delete';
import RaisedButton from 'material-ui/RaisedButton';
import FlatButton from 'material-ui/FlatButton';
import Dialog from 'material-ui/Dialog';
import Divider from 'material-ui/Divider';
import ContentAddCircle from 'material-ui/svg-icons/content/add-circle';
import {connect} from 'react-redux';
import Address from './Address';
const notselected = {
  margin: 20,padding:10,
  textAlign: 'left',
  display: 'inline-block',
};
const selected={  margin: 20,padding:10,
  textAlign: 'left',
  display: 'inline-block',border:'1px solid rgb(0, 188, 212)'}

 class CheckoutDetails extends React.Component{
constructor(props)
{super(props);
this.state={selected:null,open:false,modify:null}
this.handleAddress=this.handleAddress.bind(this);
this.handleClose=this.handleClose.bind(this);
}

handleAddress(index){
 this.setState({open: true,modify:index});
}

  handleClose() {
    this.setState({open: false,modify:null});
  }
render(){
  let iteration=[];
  const {input:{value,onChange},address,userId}=this.props;
  if(address!=undefined)
  {
    if(address.length!=0)
    {
    for(let i=0;i<address.length;i++)
  {
    iteration.push(<div key={i}><Paper style={((this.state.selected===null) ? address[i].addressDefaultFlag===true:this.state.selected===address[i].addressID) ? selected:notselected}  zDepth={1}
children={<div>
<div className="normal">
<span><ImageEdit onTouchTap={this.handleAddress.bind(null,i)}/></span><span style={{float:'right'}}><ActionDelete/></span></div>
<div className="normal">Name:{address[i].firstName} {address[i].lastName}</div>
<div className="normal">Mobile Number:{address[i].mobileNumber}</div>
<div className="normal">Alternate Mobile Number{ address[i].alternateMobileNumber!=null && address[i].mobileNumber}</div>
<div className="normal">Email Id{  address[i].alternateMobileNumber!=null && address[i].alternateMobileNumber}</div>
<div className="normal">Address:{address[i].emailId!=null && address[i].emailId}</div>
<div style={{textAlign:'center'}}><span><RaisedButton label="Deliver to this address" primary={true} onTouchTap={()=>{this.setState({selected:address[i].addressID}); onChange(address[i].addressID)}}/></span></div>
</div>}/>

</div>
                  )
    
  }
}

  else
{
  iteration.push(<p>Please set You default address</p>)
}
}


  
 
  return(<div>
  {address!=undefined && <p>Highligted One is your Default address.Please click on Delivery to this Address</p>}
  <div className="addNewAddress" onTouchTap={this.handleAddress.bind(null,null)}>
  <ContentAddCircle style={{color:'#26a69a',height:50,width:50,marginRight:10}}/> Add New Address
  </div>
  <Divider style={{marginTop:10}}/>

  {iteration}
  <Dialog
          title={this.state.modify==null ? "Save New Address":"Update Address"}
          modal={false}
          open={this.state.open}
          onRequestClose={this.handleClose}
          autoScrollBodyContent={true}
        >
          <Address initialValues={this.state.modify!=null ? this.props.address[this.state.modify] :null}/>
        </Dialog>
  </div>
)
  
}
  
}



const mapStateToProps=(state)=>{
 const {fetchmenuReducer}=state;
 const {userId,address}=fetchmenuReducer;
 return {userId,address};

}


export default connect(mapStateToProps)(CheckoutDetails);