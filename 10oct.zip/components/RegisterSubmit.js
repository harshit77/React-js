import {SubmissionError} from 'redux-form';
import {saveUserIdAfterLogin} from './../actions/actions';



const RegisterSubmit=(values,dispatch)=>{
	console.log("Inside RegisterSubmit ");
	return fetch('http://54.254.254.57:8080/hsahu/api/accounts',{
	method: 'post',mode: 'cors',credentials: 'same-origin',
	body: JSON.stringify({
		"userName":values.username,
		"password":values.password,
	}),
	headers: new Headers({
		'Content-Type': 'application/json'
	})
}).then(response =>{
	console.log("Inside RegisterSubmit ");
		if(response.status==200)
		return response.json()
		else
			throw new SubmissionError({_error:response.statusText})
        // submission was successful
      }, errors => {
        // submission was unsuccessful
      }).then((json)=>{console.log(json);

      	if(json.data!==null)
      	{
      			//do nothing 
      	}
      	else
      	{
      		throw new SubmissionError({_error:json.message})
      	}
      })
		;


// return Sleep(1000).then(()=>{
// 		if(!['harshit','Vatsalya','Rishi'].includes(values.username))
// 			 throw new SubmissionError({username:"Username does not exists",_error:"! Login Failed"})
// 		else if(values.password!=="redux-form")
// 			throw new SubmissionError({password:"Wrong password",_error:"! Login Failed"})
// 		else
// 			console.log(`You Submitted \n \n ${JSON.stringify(values,null,2)}`);
// })
}
export default RegisterSubmit;