import {SubmissionError} from 'redux-form';


const ForgetSubmit=(values,dispatch)=>{
	
	return fetch(`http://54.254.254.57:8080/hsahu/api/forget-pswd`,{
	method: 'post',mode: 'cors',credentials: 'same-origin',
	body: JSON.stringify({
		"userName":values.forgetPassword,
	}),
	headers: new Headers({
		'Content-Type': 'application/json'
	})
}).then(response =>{

		if(response.status===200)
		return response.json()
		else
			throw new SubmissionError({_error:response.statusText})
        // submission was successful
      }, errors => {
        // submission was unsuccessful
      }).then((json)=>{console.log(json);

      	if(json.data!==null)
      	{
      			//do nothing
      	}
      	else
      	{
      		throw new SubmissionError({_error:json.message});
      	}
      });
}
export default ForgetSubmit;