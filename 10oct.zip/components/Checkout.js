import React from 'react';
import {
  Step,
  Stepper,
  StepLabel,
  StepContent,
} from 'material-ui/Stepper';
import RaisedButton from 'material-ui/RaisedButton';
import FlatButton from 'material-ui/FlatButton';
import TextField from 'material-ui/TextField';
import Divider from 'material-ui/Divider';
import CheckoutDetails from './CheckoutDetails';
import DatePicker from 'material-ui/DatePicker';
import {connect} from 'react-redux';
import Dialog from 'material-ui/Dialog';
import TabsControlled from './TabsControlled';
import {Field,reduxForm} from 'redux-form';
import MenuItem from 'material-ui/MenuItem';
import SelectField from 'material-ui/SelectField'
import CheckoutSubmit from './CheckoutSubmit';
import {directAddressurl} from '../actions/actions';


const validate=values=>{
  const errors={};
  const requiredFields=['email','firstName','slotTiming','checkin_date','address'];

   requiredFields.forEach(field => {
    if (!values[field]) {
      errors[field] = 'Required'
    }
  })





  // if (
 //    values.email &&
 //    !/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(values.email)
 //  ) {
 //    errors.email = 'Invalid email address'
 //  }

 if (
    values.email &&
    (!/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(values.email) && !/^[7-9]{1}[0-9]{9}$/i.test(values.email))
  ) {
    errors.email = 'Invalid email address'
  }


   return errors;
}



const renderTextField=({
input,
label,
type,
meta:{touched,error},
custom,
})=>{
  return (
      <TextField hintText={label} type={type} floatingLabelText={label} errorText={touched && error} {...input} {...custom}/> 
    )

}

const renderSelectField=({
  input,
  label,
  meta:{touched,error},
  children
})=>{
  return(
    <SelectField 
    floatingLabelText={label}
    errorText={touched && error}
    {...input}
      onChange={(event, index, value) => input.onChange(value)}
      children={children}
        />
      )

    
    }


const renderDatePicker = ({ input, disableYearSelection,startDate, meta: { touched, error } }) => {


   return( <DatePicker 
        errorText = {touched && error} 
        {...input}
        floatingLabelText="Select your Date"
        value = {input.value !== ''? new Date(input.value) : null}
        disableYearSelection={disableYearSelection} 
        shouldDisableDate={disablePrevDate(startDate)}
        onChange = {(event, value) => {console.log(value); input.onChange(value)}} />
)}




const leaveDate=["15-8-2017","20-8-2017"];
function disablePrevDate(startDate)
{   const futureDate=new Date((new Date()).getTime() + (30 * 86400000));//disabling Future date 
  const seconds=Date.parse(startDate);
  return(date=>{
    return Date.parse(date)<= seconds || Date.parse(date) >Date.parse(futureDate) ||  (leaveDate).includes(date.getDate()+"-"+(date.getMonth()+1)+"-"+date.getFullYear().toString());
  })
} 





class Checkout extends React.Component {
constructor(props)
{super(props);
this. state = {
    finished: false,
    stepIndex: 0,selectedLoginType:false,
  disableYearSelection:false,
  autoOk:true,
  controlledDate:null,
  openCheckoutLoginDialog:false,selectOption:null
  }
this.handleNext=this.handleNext.bind(this);
 this.handleAccessClick=this.handleAccessClick.bind(this); 
this.handlePrev=this.handlePrev.bind(this);
this.handleDialogCheckoutClose=this.handleDialogCheckoutClose.bind(this);
this.renderStepActions=this.renderStepActions.bind(this);
this.selectedDelivery=this.selectedDelivery.bind(this);
this.handleSelectedLogin=this.handleSelectedLogin.bind(this);
this.handleDate=this.handleDate.bind(this);
  }
 componentDidMount(){
  if(this.props.userId!=null )
  {
     this.setState({stepIndex:1}); 
     const{dispatch}=this.props;
  if(this.props.address==undefined)
      {
        this.props.dispatch(directAddressurl()); 
      }
  }
  

 }

handleDate(event,date){
 this.setState({
      controlledDate: date,
    });

}

 handleAccessClick(selectedAcessoption,event)
{ if(selectedAcessoption!="SignOut" && selectedAcessoption!="LoginGuest")
  {console.log("selectedAcessoption",selectedAcessoption);
  this.setState({openCheckoutLoginDialog:true,selectOption:selectedAcessoption,selectedLoginType:false})
  }
  else if (selectedAcessoption=="LoginGuest")
  {
 this.setState({openCheckoutLoginDialog:false,selectOption:selectedAcessoption,selectedLoginType:true,stepIndex:1})
  }
}

handleDialogCheckoutClose()
{
  this.setState({openCheckoutLoginDialog:false})
}

componentWillReceiveProps(nextProps)
{
  if(this.props.userId!=nextProps.userId && nextProps.userId!=null)
  {
    console.log("vdnjvnd. vdnvldnvkld kv d. vdnjkvndkjvnkdv.  vdkjbvjkd componentWillReceiveProps");
    this.setState({openCheckoutLoginDialog:!this.state.openCheckoutLoginDialog,stepIndex:1,selectOption:null});
  }
  else if(nextProps.userId==null && this.state.selectOption!="LoginGuest")
  {

 this.setState({stepIndex:0,selectOption:null});
  }
}
 handleSelectedLogin(){
   this.setState({selectedLoginType:true,stepIndex:this.state.stepIndex+1})
 }
  handleNext(){
    const {stepIndex} = this.state;
    this.setState({
      stepIndex: stepIndex + 1,
      finished: stepIndex >= 2,
    });
  };

  handlePrev(){
    const {stepIndex} = this.state;
    if (stepIndex > 0) {
      this.setState({stepIndex: stepIndex - 1});
    }
    else
    {
      this.setState({selectedLoginType:false});
    }

  }
selectedDelivery(){
  this.setState({
      stepIndex: 1
  });
}
  renderStepActions(step) {
    const {stepIndex} = this.state;

    return (
      <div style={{margin: '12px 0'}}>
        <RaisedButton
          label={stepIndex === 3 ? 'Finish' : 'Next'}
          disableTouchRipple={true}
          disabled={this.props.invalid}
          disableFocusRipple={true}
          primary={true}
          type={stepIndex === 3 ? 'submit' : 'button'}
          onTouchTap={this.handleNext}
          style={{marginRight: 12}}
        />
        {step >=0 && (
          <FlatButton
            label="Back"
            disabled={(this.props.userId!=null && step===1) ? true :false}
            disableTouchRipple={true}
            disableFocusRipple={true}
            onTouchTap={this.handlePrev}
          />
        )}
      </div>
    );
  }

  render() {
    console.log("Inside Checkjout",this.state.controlledDate);
    const {userId,cartDetails}=this.props;
    const {handleSubmit,pristine,reset,submitting,saveState,invalid}=this.props;
      console.log("Inside Checkjout",cartDetails,userId,this.state.stepIndex);
    const startDate=new Date();
    startDate.setDate(startDate.getDate()-1);
    const {finished, stepIndex} = this.state;

    return (
      <div>
       {cartDetails[0].cart_items!=null && 

      <div className="row features-grid">
      <div style={{maxWidth:380, margin: 'auto'}}>
       <form onSubmit={handleSubmit(CheckoutSubmit)}>
        <Stepper activeStep={stepIndex} orientation="vertical">
          
          <Step>
            <StepLabel>Select Login Type</StepLabel>
            <StepContent>
              <div className="normal">
        {userId==null && <div style={{marginTop:25}}>
       
        <RaisedButton
          label="Login"          
          primary={true} style={{marginLeft:20}}
        onTouchTap={this.handleAccessClick.bind(null,"Login")}     
        />
    <Divider style={{marginTop:10,marginBottom:10}}/>
    <RaisedButton label="Login in as Guest" labelColor="#fff" style={{marginLeft:20}} backgroundColor="rgb(38, 166, 154)" onTouchTap={this.handleAccessClick.bind(null,"LoginGuest")}/>
  </div>
        }
      
 
   
              </div>
             
            </StepContent>
          </Step>
    
          <Step>
            <StepLabel>Select Address</StepLabel>
            <StepContent>
       
           <div>
           
            <Field name="address" component={CheckoutDetails} label="First Name" type="text" />
          </div>
    
              {this.renderStepActions(1)}
            </StepContent>
          </Step>
          <Step>
            <StepLabel>Select Date</StepLabel>
            <StepContent>
              <div>
                Try out different ad text to see what brings in the most customers
                <Field name="checkin_date" component={renderDatePicker} hintText="Checkin Date" disableYearSelection={this.state.disableYearSelection} startDate={startDate} autoOk={this.state.autoOk} />
             </div>
              {this.renderStepActions(2)}
            </StepContent>
          </Step>

          <Step>
            <StepLabel>Select Slot Timing</StepLabel>
            <StepContent>
         
               <div>
               <Field
                      name="slotTiming"
                      component={renderSelectField}
                      label="Select Slot Timing"
                    >
                      <MenuItem value="ff0000" primaryText="Red" />
                      <MenuItem value="00ff00" primaryText="Green" />
                      <MenuItem value="0000ff" primaryText="Blue" />
                    </Field>

          </div>
          {this.renderStepActions(3)}



            </StepContent>
          </Step>


        </Stepper>
        {finished }
        </form>
    </div>
      </div>
   }
    
     {cartDetails[0].cart_items==null && 
      <div className="selectedcategorytitle" style={{padding:'50px 0px 8px',textAlign:'center'}}>You have Nothing in your Chart</div>
 
    }


 <Dialog
          
          modal={false}
          autoScrollBodyContent={true}
          open={this.state.openCheckoutLoginDialog}
          onRequestClose={this.handleDialogCheckoutClose}
        >
        {this.state.selectOption==="Login" ? <TabsControlled/>:null }
    
        </Dialog>


    </div>
    );
  }
}


Checkout=reduxForm({
  form:'checkout',
  validate,
})(Checkout);


const mapStateToProps=(state)=>{
 const {fetchmenuReducer}=state;
 const {userId,cartDetails,address}=fetchmenuReducer;
 return {userId,cartDetails,address};

}


export default connect(mapStateToProps)(Checkout);
