import React from 'react';
import {Field,reduxForm} from 'redux-form';
import Checkbox from 'material-ui/Checkbox';
import TextField from 'material-ui/TextField';
import MenuItem from 'material-ui/MenuItem'
import SelectField from 'material-ui/SelectField'
import {intialState} from './../actions/actions';
import {connect} from 'react-redux';
import ForgetSubmit from './ForgetSubmit';
import RaisedButton from 'material-ui/RaisedButton';
import Divider from 'material-ui/Divider';
import Subheader from 'material-ui/Subheader';
import CircularProgress from 'material-ui/CircularProgress';

const validate=values=>{
	const errors={};
	const requiredFields=['forgetPassword'];

	 requiredFields.forEach(field => {
    if (!values[field]) {
      errors[field] = 'Required'
    }
  })



 if (
    values.forgetPassword &&
    (!/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(values.forgetPassword) && !/^[7-9]{1}[0-9]{9}$/i.test(values.forgetPassword))
  ) {
    errors.forgetPassword = isNaN(values.forgetPassword)===true ?'Invalid email address' :"Invalid Mobile Number";
  }
	 return errors;
}


const renderTextField=({
input,
label,
type,
meta:{touched,error},
custom,
})=>{
	return (
			<TextField hintText={label} type={type} floatingLabelText={label} errorText={touched && error} {...input} {...custom}/> 
		)

}


class ForgetPassword extends React.Component
{
	constructor(props)
	{
		super(props)
	}
	render()
	{
		const {error,handleSubmit,pristine,invalid,reset,submitting,submitSucceeded}=this.props;
		return(<div style={{textAlign:'center'}}>
			
				{submitting===false ?
					<form onSubmit={handleSubmit(ForgetSubmit)}>
				<div>
				{submitSucceeded===true && <p className="success">We have Sent </p> }
				</div>
				<Subheader style={{color:'red'}}>
				{error && <strong>{error}</strong>}
				</Subheader>
					<div>
					<Field name="forgetPassword" component={renderTextField} label="Mobile Number or Email id" type="text"/>
					</div>
					
					<div>
					<RaisedButton
          label="Help"          
          primary={true} style={{margin:'20px 0'}}
          disabled={invalid || pristine || submitting}
		       type="submit"    
        />
					 </div>
				</form>
				:
				<CircularProgress size={80} thickness={5} />
			}
 		

				</div>
				




			  )
	}

}

ForgetPassword=reduxForm({
	form:'ForgetPassword',
	validate
})(ForgetPassword);





export default ForgetPassword;