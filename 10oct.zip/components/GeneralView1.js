import React from 'react';
import Chip from 'material-ui/Chip';
import Paper from 'material-ui/Paper';
import FlatButton from 'material-ui/FlatButton';
import RaisedButton from 'material-ui/RaisedButton';
import {connect} from 'react-redux';
import CircularProgress from 'material-ui/CircularProgress';

const styles={
chip:{margin:4,float:'left',
height: 33,border:'1px solid rgb(0, 188, 212)'}
	

}

 class GeneralView1 extends React.Component{
	constructor(props)
	{
		super(props);
		this.state={open:false,fileName:null,disabled:true};
		this.handleTouchTap=this.handleTouchTap.bind(this);

	}
	handleTouchTap()
	{
		alert("CLick");
	}
	

	render()
	{ 	const chip=[];
		const  {isFetching,items,specialOffers}=this.props;


 const actions = [
      <FlatButton
        label="Cancel"
        primary={true}
        onTouchTap={this.handleClose}
      />,
      <FlatButton
        label="Upload It"
        primary={true}
		disabled={this.state.disabled}
        keyboardFocused={true}
        onTouchTap={this.handleClose}
      />,
    ];
	return(
		
		<div className="container">
	 <div className="row">
	 <Paper className="specialOffer" zDepth={3} children={
	 <div className="col-lg12 col-xs-12 col-sm-12 col-md-12">
	 {isFetching && specialOffers===undefined && <div className="alignCenter-specialOffer-Loader"><CircularProgress size={40} thickness={4} /><div className="selectedcategorytitle">Fetching Our Special Offers</div></div>}	
	{ !isFetching && specialOffers!=undefined && specialOffers.map((item,index)=>
		 {return(<Chip style={styles.chip} key={index} onTouchTap={this.handleTouchTap}>{`SpecialOffers ${index+1} `}</Chip>)

		 }
		 )}
	
	</div>
}
	 />
	 </div>	
		</div>
		)
	}
} 

const mapStateToProps=(state,ownProps)=>{
	const {fetchmenuReducer}=state;
const {isFetching,items,years,submenu,specialOffers}=fetchmenuReducer;
console.log("Special Offers",specialOffers);
return {isFetching,items,years,submenu,specialOffers};

}

export default connect(mapStateToProps)(GeneralView1);