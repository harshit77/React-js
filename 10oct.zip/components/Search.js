import React from 'react';
import {fetchSearchProduct} from '../actions/actions';
import {connect} from 'react-redux';
class Search extends React.Component
{
	constructor(props)
	{
		super(props);
	}
	componentDidMount()
	{
		const {dispatch}=this.props;
		dispatch(fetchSearchProduct(this.props.params.searchId));
	}

	render()
	{
		return(
			<div className="col-lg-9 col-md-9 col-xs-12 col-sm-12" style={{borderLeft:'10px solid transparent'}}>
				 <div className="row shopcategoriesSection">
				      <div className="selectedcategorytitle">Result Found</div>
				      </div>
			</div>

			)
	}
}

const mapStateToProps=(state,ownProps)=>{
	const {fetchmenuReducer,searchDataSource}=state;
const {isFetching,items,cartDetails,status,userId}=fetchmenuReducer;
const{isSearchFetching,dataSource,dataSourceLocally}=searchDataSource;

return {isFetching,items,isSearchFetching,dataSource,dataSourceLocally,cartDetails,status,userId};

}

export default connect(mapStateToProps)(Search);