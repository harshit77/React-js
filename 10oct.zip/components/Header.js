import React from 'react';
import AppBar from 'material-ui/AppBar';
import IconMenu  from 'material-ui/IconMenu';
import MenuItem from 'material-ui/MenuItem';
import IconButton from 'material-ui/IconButton/IconButton';
import AutoComplete from 'material-ui/AutoComplete';
import TextField from 'material-ui/TextField';
import MapsPlace  from 'material-ui/svg-icons/maps/place';
import Avatar from 'material-ui/Avatar';
import {List, ListItem} from 'material-ui/List';
import NavigationMenu from 'material-ui/svg-icons/navigation/menu';
import SocialPersonOutline from 'material-ui/svg-icons/social/person-outline';
import SocialPersonAdd from 'material-ui/svg-icons/social/person-add';
import NotificationsIcon from 'material-ui/svg-icons/social/notifications';
import Dialog from 'material-ui/Dialog';
import FlatButton from 'material-ui/FlatButton';
import ActionDeleteForever from 'material-ui/svg-icons/action/delete-forever';
import Quantity from './Quantity';
import Badge from 'material-ui/Badge';
import Drawer from 'material-ui/Drawer';
import Subheader from 'material-ui/Subheader';
import CircularProgress from 'material-ui/CircularProgress';
import {connect} from 'react-redux';
import {Link} from 'react-router';
import TabsControlled from './TabsControlled';
import ChangePassword from './ChangePassword';
import Divider from 'material-ui/Divider';
import {hashHistory} from 'react-router';
import Profile from './Profile';
import {select_submenu,selected_menu_click,fetchsubitem,fetchmenus,recieve_product_status,searchrequest,searchlocally,fetch_product_status,} from '../actions/actions';


const loaderforSearch={position:'absolute',
    top: -23,
    right: 135}
const subHeaderStyle={color:"#00B9F5",
    fontWeight: 600,
    fontSize: 16};
class Header extends React.Component{
	constructor(props)
	{
		super(props);
		
		this.state={open:false,openDrawer:false,searchrepository:null,initallocalrepository:false,openDialog:false,selectOption:null};
	this.handleOpen=this.handleOpen.bind(this);
		this.handleClose=this.handleClose.bind(this);
		this.handleDrawerClose=this.handleDrawerClose.bind(this);
		this.handleDrawerMenu=this.handleDrawerMenu.bind(this);
		this.handleClick=this.handleClick.bind(this);
		this.handleRequestChange=this.handleRequestChange.bind(this);
		this.searchSomething=this.searchSomething.bind(this);
		this.handleproductQuantityChange=this.handleproductQuantityChange.bind(this);
		this.handleProductDelete=this.handleProductDelete.bind(this);
		this.handleAccessClick=this.handleAccessClick.bind(this);
		this.handleDialogClose=this.handleDialogClose.bind(this);
		this.handleNewRequest=this.handleNewRequest.bind(this);
	}
	componentDidMount(){const{dispatch}=this.props;
	dispatch(fetchmenus());
}
componentWillReceiveProps(nextProps)
{
	if(this.props.userId!=nextProps.userId)
	{
		console.log("componentWillReceiveProps");
		this.setState({openDialog:!this.state.openDialog});
	}
}
handleDialogClose()
{
	this.setState({openDialog:false,selectOption:null})
}
handleAccessClick(selectedAcessoption,event)
{	if(selectedAcessoption!="SignOut")
	{console.log("selectedAcessoption",selectedAcessoption);
	this.setState({openDialog:true,selectOption:selectedAcessoption})
	}
}

handleNewRequest(searchItem,indexofSearchItem)
{
	alert(searchItem.valueKey);
console.log("Search item Cliked",searchItem);
const path = `/search/${searchItem}`;
hashHistory.push(path);
}

searchSomething(value){
	console.log("dataSource"+this.props.dataSourceLocally);
	console.log("dsd"+this.props.dataSourceLocally.toString().indexOf(value));
	if(value.length>=1 &&  this.props.dataSourceLocally.toString().indexOf(value) == -1 && this.state.initallocalrepository==true){
		console.log("Request Start from Here");
this.props.dispatch(searchrequest(value));
this.setState({searchrepository:1});
}
else
{
console.log("I have Values");
this.props.dispatch(searchlocally(value));
this.setState({searchrepository:0,initallocalrepository:true});
}
}

	  handleOpen(){
    this.setState({open: true});
  }
  handleClose(){
    this.setState({open: false});
  }
  handleDrawerClose(){
	this.setState({openDrawer:false});	
}
handleDrawerMenu(){
	
	this.setState({openDrawer:true});	
}
handleClick(item,layout,event)
	{ $('html, body').animate({
        scrollTop: $(".features-grid").offset().top-60
    }, 2000);
	this.setState({openDrawer:false});
 this.props.dispatch(selected_menu_click(item));
	}
	handleRequestChange(open)
	{ this.setState({openDrawer: open});
		
	}
	handleproductQuantityChange(changedValue,productId)
	{
 this.props.dispatch(fetch_product_status(productId,this.props.cartDetails[0].cart_id,changedValue));
     
	}
	handleProductDelete(changedValue,productId)
	{
		this.props.dispatch(fetch_product_status(productId,this.props.cartDetails[0].cart_id,changedValue));
  
	}
	render(){
		console.log("State of repository "+this.state.searchrepository);
		const {items,isFetching,isSearchFetching,dataSource,dataSourceLocally,cartDetails,status,userId}=this.props;
		console.log("Inside Header ",cartDetails);
		 const actions = [
      <FlatButton
        label="Cancel"
        primary={true}
        onTouchTap={this.handleClose}
      />,
     <FlatButton
        label="Submit"
        primary={true}
     
 containerElement={<Link to="/checkout"/>}
 
        onTouchTap={this.handleClose}
	    style={{overflow:'none'}} />,
    ];

let dt=[];
	 dt=dataSource;
	 const dataSourceConfig = {
  text: 'textKey',
  value: 'valueKey',
};
		return (
		<AppBar 
		title="Title" iconStyleRight={{width:"80%",marginTop:0}}  titleStyle={{color:"rgb(0, 188, 212)"}} style={{backgroundColor:"#fff",position:"fixed",boxShadow: "rgba(0, 0, 0, 0.298039) 0px 19px 60px, rgba(0, 0, 0, 0.219608) 0px 15px 20px"}}
		 iconElementLeft={<IconButton  onTouchTap={this.handleDrawerMenu} tooltip="Menu" tooltipPosition="bottom-center" iconStyle={{fill:"rgb(0, 188, 212)"}}><NavigationMenu/>
		
		 		 </IconButton>}
		iconElementRight={
		<div>
		<div className="visible-sm-inline-block visible-md-inline-block visible-lg-inline-block" style={{width:"88%"}}>

    <AutoComplete className="searchbox"
          floatingLabelText='Search for Products e.g Panner'
         
          dataSource={(this.state.searchrepository==1) ? dt:dataSourceLocally}
        dataSourceConfig={dataSourceConfig}
          onUpdateInput={this.searchSomething}
     fullWidth={true}
     onNewRequest={this.handleNewRequest}
     hintText="All OK"
    listStyle={{ maxHeight:'50vw', overflow: 'auto' }}
      openOnFocus={true}
     maxSearchResults={25}
         filter={AutoComplete.fuzzyFilter} />
     {isSearchFetching==true && <div style={loaderforSearch}><div className="alingCenter"><CircularProgress size={30} thickness={4} /></div></div>}
	</div>
		<div className="visible-xs-inline-block" style={{width:"88%"}}>
  <AutoComplete className="searchbox"
          floatingLabelText='Search for Products e.g Panner'
          dataSource={(this.state.searchrepository==1)? dt:dataSourceLocally}
           dataSourceConfig={dataSourceConfig}
        onUpdateInput={this.searchSomething}
     fullWidth={true} 
        textFieldStyle={{width: '150%'}}
     onNewRequest={this.handleNewRequest}
       hintText="All OK"
     listStyle={{ maxHeight:'50vw', overflow: 'auto' }}
      openOnFocus={true}
           filter={AutoComplete.fuzzyFilter} />
            {isSearchFetching==true && <div style={loaderforSearch}><div className="alingCenter"><CircularProgress size={30} thickness={4} /></div></div>}
	</div>

{(this.props.userId===null || this.props.userId===undefined) ?

	<IconMenu style={{position:"fixed",right: 0,top:10}}
iconButtonElement={<IconButton tooltip="Login" tooltipPosition="bottom-center" ><SocialPersonOutline /></IconButton>}
	anchorOrigin={{horizontal:'left',vertical:'top'}} targetOrigin={{horizontal:'left',vertical:'top'}} maxHeight={272} >
		<MenuItem primaryText="Refresh" />
      <MenuItem primaryText="Login" onTouchTap={this.handleAccessClick.bind(null,"Login")} />
     
		</IconMenu>:


<IconMenu style={{position:"fixed",right: 0,top:10}}
iconButtonElement={<IconButton tooltip="Login" tooltipPosition="bottom-center" ><SocialPersonAdd /></IconButton>}
	anchorOrigin={{horizontal:'left',vertical:'top'}} targetOrigin={{horizontal:'left',vertical:'top'}} maxHeight={272} >
	<MenuItem primaryText="Profile" onTouchTap={this.handleAccessClick.bind(null,"Profile")}/>
	<MenuItem primaryText="ChangePassword" onTouchTap={this.handleAccessClick.bind(null,"ChangePassword")}/>
	 <Divider />
      <MenuItem primaryText="Sign out" />
		</IconMenu>




	}
		 <IconMenu style={{position:"fixed",right:37,top:10}} 
     iconButtonElement={<IconButton tooltip="Change Location" tooltipPosition="bottom-center" iconStyle={{fill:"rgb(0, 188, 212)"}}><MapsPlace/></IconButton>} 
      anchorOrigin={{horizontal: 'left', vertical: 'top'}}
      targetOrigin={{horizontal: 'left', vertical: 'top'}}
    >
      <MenuItem primaryText="Lucknow" />
      <MenuItem primaryText="Agra" />
     
    </IconMenu>
		<Badge
		badgeContent={(cartDetails==null || cartDetails==undefined)  ? 0:(cartDetails[0].cart_items==null ? 0:cartDetails[0].cart_items.length)} primary={true} style={{position:"fixed",right:87,cursor:'pointer',width:22,height:22}} badgeStyle={{top:7,right:-10,width:20,height:20}}> 
		<NotificationsIcon onTouchTap={this.handleOpen}/>
		</Badge>
		<Dialog
          title={<div><div>Your Cart</div><div style={{float:'right',position:'relative',top:-30}}>OrderTotal : Rs {(cartDetails!=undefined  && cartDetails[0].cart_items!=null) ? cartDetails[0].order_total : 0}</div></div>}
          actions={actions}
          modal={false}
          titleStyle={{fontSize:'1.2em'}}
          bodyStyle={{width:'100%'}}
          open={this.state.open}
          onRequestClose={this.handleClose}
          autoScrollBodyContent={true}
        >
          <List>
		  {cartDetails!=undefined  && cartDetails[0].cart_items!=null && cartDetails[0].cart_items.map((addedItem,i)=>{
			 return( <ListItem
          key={i} disabled={true}
          primaryText={<div><p style={{float:'left',margin:'17px 0 10px'}}>{addedItem.name}</p><Quantity productId={addedItem.id} productPrice={addedItem.productPrice} productQuantityChange={this.handleproductQuantityChange} productQuantity={addedItem.productQuantity}/></div>}
          secondaryText={<div>{addedItem.productQuantity} x {addedItem.productPrice}</div>}
          leftAvatar={<div><Avatar src={addedItem.imgUrl} /></div>}
          rightIcon={<ActionDeleteForever onTouchTap={this.handleProductDelete.bind(null,0,addedItem.id)} />}
		  />) 
		  })
		  }
      </List>
        </Dialog>
		 <Drawer 
		docked={false} 
		width={250}
		open={this.state.openDrawer}
		 onRequestChange={this.handleRequestChange}
		 >

		 <Subheader style={subHeaderStyle}>Shop by Category</Subheader>
	 {isFetching && items.length==0 && <div className="alingCenter"><CircularProgress size={60} thickness={7} /></div>}	
			{!isFetching && items.map((item,i)=>
		 {return(<Link to={`/paytm/${item}`} key={i} ><MenuItem  className="listitem" innerDivStyle={{fontSize:'1.4rem',textTransform:'uppercase',padding:10,lineHeight:0,marginTop:10}}
		 
		 primaryText={item} key={i} ref={item} onTouchTap={this.handleClick.bind(null,item,1)}
		 />	 </Link>
)
		 }
		 )}
		
		</Drawer>

{this.state.selectOption!=null &&
		 <Dialog
          
          title={this.state.selectOption==="ChangePassword" ? "Change Password":(this.state.selectOption==="Profile" ? "Profile" :null)}
          modal={false}
          autoScrollBodyContent={true}
          repositionOnUpdate={true}
          open={this.state.openDialog}
          onRequestClose={this.handleDialogClose}
        >
        {this.state.selectOption==="Login" ? <TabsControlled/>:(this.state.selectOption==="ChangePassword" ? <ChangePassword initialValues={{userName:userId}}/>:(this.state.selectOption==="Profile" ? <Profile/>:null)) }
    
        </Dialog>
    }
		</div>
		}/>
		)
	}
}



const mapStateToProps=(state,ownProps)=>{
	const {fetchmenuReducer,searchDataSource}=state;
const {isFetching,items,cartDetails,status,userId}=fetchmenuReducer;
const{isSearchFetching,dataSource,dataSourceLocally}=searchDataSource;

return {isFetching,items,isSearchFetching,dataSource,dataSourceLocally,cartDetails,status,userId};

}

export default connect(mapStateToProps)(Header);