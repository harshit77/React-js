const constants={
	INCREMENT:"INCREMENT",
	DECREMENT:"DECREMENT"
}

export default constants;