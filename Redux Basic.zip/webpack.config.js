module.exports={
	entry:'./app.js',
	output:{
	path:__dirname + "/ouput" ,
	filename:'index.js'
	},
	devServer:{
		inline:true,
		port:1000
	},
	module:{
	loaders:[
		{
			test:/\.js?$/,
			exclude:/node_module/,
			loader:'babel-loader',
			
			query:{
				presets:['es2015','react']
			}
		}
	]
	}
}