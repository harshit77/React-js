import React from 'react';
import {Action1,Action2} from './action.js';
import {connect} from 'react-redux';
import Counter1 from './Counter1.js';
import ReactDOM  from 'react-dom';
import {createStore,applyMiddleware,combineReducers} from 'redux';import { Provider } from 'react-redux';
import {first} from './reducer.js';import createLogger from 'redux-logger';
import thunkMiddleware  from 'redux-thunk';
const loggerMiddleware=createLogger();
const reducer=combineReducers({
	first
});
const store = createStore(reducer,applyMiddleware(thunkMiddleware,loggerMiddleware));
class Counter extends React.Component{
	constructor(props){
		super(props);
		this.handleClick=this.handleClick.bind(this);

	}
	handleClick(actionType,event)
	{ const{dispatch}=this.props;
		const value=document.getElementById("value").textContent;
	console.log("Value After Click"+value);
if(actionType===1)
{	store.dispatch(Action1(value));}
else
{		store.dispatch(Action2(value));}

}
	
	render(){

		const {First}=this.props;
		return(
			<div>
			<Counter1/>
			</div>
		) 
	}
}




ReactDOM.render(<Provider store={store}>
    <Counter />
  </Provider>,document.getElementById('app'))