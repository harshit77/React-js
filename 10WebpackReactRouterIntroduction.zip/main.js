import React from 'react';
import ReactDOM from 'react-dom';
import {Router,Route,IndexRoute,Link,hashHistory} from 'react-router';
class App extends React.Component {
	constructor(props)
	{
		super(props);
	}
	render(){
		return(
		<div>
		<h1>App</h1>
		<ul>
		<li><Link to="/about">About</Link>
		</li>
		<li><Link to="/inbox">Inbox</Link>
		</li>
		</ul>
		{this.props.children}
				</div>
		
		)
		
	}
	
}

class Home extends React.Component{
	render(){
		return(
		<div>Home</div>
		)
	}
}

class About extends React.Component{
	render(){
		return(
		<div>About</div>
		)
	}
}
class Inbox extends React.Component{
	render(){
		return(
		<div>Inbox
		{/* Render the child route component */}
		{this.props.children}
		</div>
		
		)
	}
	
}
class InboxStats extends React.Component{
	render(){
		return(
		<div>InboxInboxStats</div>
		)
	}
	
}
class Messages extends React.Component{

	componentDidMount(){
		const id=this.props.params.id;
		console.log("Messages with id "+id)
	}
	render(){
		return(
		<div>Messages {this.props.params.id}</div>
		)
	}
	
}
ReactDOM.render(<Router history={hashHistory}>
<Route path="/" component={App}>
     <IndexRoute component={Home}/>
     <Route path="about" component={About}/>
     <Route path="inbox" component={Inbox}>
     <IndexRoute component={InboxStats}/>
     <Route path="messages/:id" component={Messages}/>
     </Route>
</Route>
</Router>,document.getElementById("app"));
