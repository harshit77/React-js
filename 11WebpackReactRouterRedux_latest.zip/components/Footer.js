import React from 'react';
import ActionRedeem from 'material-ui/svg-icons/action/redeem';
import CommunicationPhone from 'material-ui/svg-icons/communication/phone';
import {BottomNavigation, BottomNavigationItem} from 'material-ui/BottomNavigation';
import IconLocationOn from 'material-ui/svg-icons/communication/location-on';
import Paper from 'material-ui/Paper';
const recentIcon=<ActionRedeem/>;
const nearbyIcon = <IconLocationOn />;
const favoriteIcon=<CommunicationPhone/>;
export default class Footer extends React.Component{  
constructor(props)
{
	super(props);
	this.state = {selectedIndex: 0}
this.select=this.select.bind(this);
  }

  select(index,event){
this.setState({selectedIndex: index});
  } 
  render() {
    return (
      <Paper zDepth={1}>
        <BottomNavigation selectedIndex={this.state.selectedIndex}>
          <BottomNavigationItem
            label="Recents"
            icon={recentIcon}
            onTouchTap={this.select.bind(null,0)}
          />
          <BottomNavigationItem
            label="Favorite"
            icon={favoriteIcon}
            onTouchTap={this.select.bind(null,1)}
          />
		   <BottomNavigationItem
            label="Nearby"
            icon={nearbyIcon}
            onTouchTap={this.select.bind(null,2)}
       />
        </BottomNavigation>
		
		{this.state.selectedIndex==2 &&
		<div className="container footer_Container">
		<h1 className="aligncenter">About Paytm</h1>
		<div className="row">
		<div className="footer_details">
		Paytm is India's largest mobile payments and commerce platform. It started with online mobile recharge
		and bill payments and has an online marketplace today. In a short span of time we have scaled to over 164Mn registered users and more than 90Mn monthly transactions. Paytm is the consumer brand of India's leading mobile internet company One97 Communications. One97 investors include Ant Financial (AliPay), SAIF Partners, Mediatek, Sapphire Venture and Silicon Valley Bank. We strive to maintain an open culture where everyone is a hands-on contributor and 
		feels comfortable sharing ideas and opinions. Our team spends hours designing each new feature and obsesses about the smallest of details.</div>
		
		</div>
		
		</div>
		
		
		}
      </Paper>
    );
  }
}