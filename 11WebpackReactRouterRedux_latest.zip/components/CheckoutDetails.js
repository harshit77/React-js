import React from 'react';
import Paper from 'material-ui/Paper';
import ImageEdit from 'material-ui/svg-icons/image/edit';
import ActionDelete from 'material-ui/svg-icons/action/delete';
import RaisedButton from 'material-ui/RaisedButton';
import FlatButton from 'material-ui/FlatButton';
import Dialog from 'material-ui/Dialog';
import Divider from 'material-ui/Divider';
import ContentAddCircle from 'material-ui/svg-icons/content/add-circle';
const notselected = {
  margin: 20,padding:10,
  textAlign: 'left',
  display: 'inline-block',
};
const selected={  margin: 20,padding:10,
  textAlign: 'left',
  display: 'inline-block',border:'1px solid rgb(0, 188, 212)'}

export default class CheckoutDetails extends React.Component{
constructor(props)
{super(props);
this.state={selected:null,open:false}
this.handleTouchTap=this.handleTouchTap.bind(this);
this.handleAddress=this.handleAddress.bind(this);
this.handleClose=this.handleClose.bind(this);
}

handleAddress(){
 this.setState({open: true});
}
handleTouchTap(i,event){
	console.log("Clicked ityem"+i);
this.setState({selected:i});
this.props.selectedDelivery();
	
}
  handleClose() {
    this.setState({open: false});
  }
render(){
	const iteration=[];
	for(let i=0;i<2;i++)
	{
		iteration.push(<div key={i}><Paper style={this.state.selected===i ? selected:notselected}  zDepth={1}
children={<div>
<div className="normal">
<span><ImageEdit onTouchTap={this.handleAddress}/></span><span style={{float:'right'}}><ActionDelete/></span></div>
<div className="normal">Terrence S. Hatfield</div>
<div className="normal">Phone Number: 651-603-1723 </div>
<div className="normal">Email: TerrenceSHatfield@rhyta.com</div>
<div style={{textAlign:'center'}}><span><RaisedButton label="Primary" primary={true} onTouchTap={this.handleTouchTap.bind(null,i)}/></span></div>
</div>}/>

</div>
)
		
	}
	const actions = [
      <FlatButton
        label="Cancel"
        primary={true}
        onTouchTap={this.handleClose}
      />,
      <FlatButton
        label="Submit"
        primary={true}
        keyboardFocused={true}
        onTouchTap={this.handleClose}
      />,
    ];
	return(<div>
	<div className="addNewAddress" onTouchTap={this.handleAddress}>
	<ContentAddCircle style={{color:'#26a69a',height:50,width:50,marginRight:10}}/> Add New Address
	</div>
	<Divider style={{marginTop:10}}/>
	{iteration}
	<Dialog
          title="Dialog With Actions"
          actions={actions}
          modal={false}
          open={this.state.open}
          onRequestClose={this.handleClose}
        >
          The actions in this window were passed in as an array of React objects.
        </Dialog>
	</div>
)
	
}
	
}
