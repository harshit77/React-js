import React from 'react';
import Chip from 'material-ui/Chip';
import Paper from 'material-ui/Paper';
import Avatar from 'material-ui/Avatar';
import FlatButton from 'material-ui/FlatButton';
import RaisedButton from 'material-ui/RaisedButton';

const styles={
chip:{margin:4,float:'left',
height: 33,border:'1px solid rgb(0, 188, 212)'}
	

}

export default class GeneralView1 extends React.Component{
	constructor(props)
	{
		super(props);
		this.state={open:false,fileName:null,disabled:true};
		this.handleTouchTap=this.handleTouchTap.bind(this);

	}
	handleTouchTap()
	{
		alert("CLick");
	}
	

	render()
	{ 	const chip=[];
for(var i=0;i<10;i++)
{
	chip.push(<Chip style={styles.chip} key={i} onTouchTap={this.handleTouchTap}><Avatar style={{backgroundColor:"rgb(0, 188, 212)",color:"#fff"}}size={32}>{`A${i+1}`}</Avatar>{`Text ${i+1} `}</Chip>)
}
 const actions = [
      <FlatButton
        label="Cancel"
        primary={true}
        onTouchTap={this.handleClose}
      />,
      <FlatButton
        label="Upload It"
        primary={true}
		disabled={this.state.disabled}
        keyboardFocused={true}
        onTouchTap={this.handleClose}
      />,
    ];
	return(
		
		<div className="container">
	 <div className="row">
	 <Paper className="specialOffer" zDepth={3} children={
	 <div className="col-lg12 col-xs-12 col-sm-12 col-md-12">{chip}</div>
	}/>
	 </div>	
		</div>
		)
	}
} 