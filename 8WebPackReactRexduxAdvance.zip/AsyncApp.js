import React from 'react';
import {connect} from 'react-redux';
import {select_subreddit,fetchpostifNeeded} from './actions/actions';
import Posts from './Posts';
import Picker from './Picker';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
injectTapEventPlugin();
import injectTapEventPlugin from 'react-tap-event-plugin';
class AsyncApp extends React.Component{
constructor(props){
	super(props);
	this.handleChange = this.handleChange.bind(this);
}
componentDidMount()
{const{dispatch,selectedSubRedit}=this.props;
dispatch(fetchpostifNeeded(selectedSubRedit));
}
componentWillReceiveProps(nextProps) {

    if (nextProps.selectedSubRedit !== this.props.selectedSubRedit) {
      const { dispatch, selectedSubRedit } = nextProps;

      dispatch(fetchpostifNeeded(selectedSubRedit));
    }
  }
  handleChange(nextSubreddit) {
    this.props.dispatch(select_subreddit(nextSubreddit));
  }

render(){
	const {selectedSubRedit,isFetching,items,lastUpdated}=this.props;
return (
<div>
<MuiThemeProvider>
<Picker value={selectedSubRedit} onChange={this.handleChange} options={['reactjs','frontend']} />
</MuiThemeProvider>
{isFetching && items.length===0 &&
<h2>Loading...</h2>}
{items.length>0 &&
<div style={{opacity:isFetching ? 0.5:1}}>
<Posts posts={items}></Posts>
</div>	
}

</div>
)
	
}
	
	
	
}
function mapStateToProps(state)
{
	const {selectedSubRedit,postReducers}=state;
	const{isFetching,
	lastUpdated,
	items}=postReducers[selectedSubRedit]||{isFetching:false,items:[]};
	
	return {
    selectedSubRedit,
    items,
    isFetching,
    lastUpdated
  }
}

export default connect(mapStateToProps)(AsyncApp);