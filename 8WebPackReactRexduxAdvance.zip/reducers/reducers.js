import {combineReducers} from 'redux';
import {SELECT_SUBREDDIT, REQUEST_POST,RECIEVE_POST} from '../actions/actions';

function selectedSubRedit(state="reactjs",action){
	
	switch(action.type)
	{
	case SELECT_SUBREDDIT: return action.subreddit;
     default: return state;
	}
}
function post(state={
	isFetching:false,
	didInvalidate:false,
	items:[]
},action){
	
	switch(action.type){
		case REQUEST_POST:
		                       return Object.assign({},state,{ 
							   isFetching:true,
							   didInvalidate:false
							   }) ;
 case RECIEVE_POST:			
    return Object.assign({},state,{
		isFetching:false,
		didInvalidate:false,
		items:action.posts,
		lastUpdated:action.recievedAt
	}) ;
	default: return state;
		
		
	}
}

function postReducers(state={},action)
	{
		switch(action.type){
			case REQUEST_POST :
			case RECIEVE_POST : 
			return Object.assign({},state,{
				[action.subreddit]:post(state[action.subreddit],action)
			});
			default: return state;
		}
	}

const rootReducer=combineReducers({
	postReducers,
	selectedSubRedit
});


export default rootReducer;