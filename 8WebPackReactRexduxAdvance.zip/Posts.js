import React from 'react';


export default class Posts extends React.Component{
	render(){
     return (
	 <ul>
	 { 
		 this.props.posts.map((item,i)=>
	 <li key={i}>{item.title}
	 </li>
	 
	 )}
	 </ul>
	 
	 )		
		
	}
}

Posts.propTypes = {
  posts: React.PropTypes.array.isRequired
}