import React from 'react';
import SelectField from 'material-ui/SelectField';
import MenuItem from 'material-ui/MenuItem';
export default class Picker extends React.Component{
	constructor(props){
		super(props);
		this.handleChangePicker=this.handleChangePicker.bind(this);
	}
	render(){
		const{value,onChange,options}=this.props;
		return (
		<span>
		<h1>{value}</h1>
		<SelectField  value={value}  onChange={this.handleChangePicker} >
            {options.map(option =><MenuItem  value={option} primaryText={option}/>)
          }
        </SelectField>
		
		</span>
		)
		
	}
	handleChangePicker(event, index, value){
	this.props.onChange(value);
	}
}