import fetch from 'isomorphic-fetch';

export const SELECT_SUBREDDIT="SELECT_SUBREDDIT";

export function select_subreddit(subreddit){
	return {
		type:SELECT_SUBREDDIT,
		subreddit
	}
	
}
export const REQUEST_POST="REQUEST_POST";


export function request_post(subreddit){
	return {
		type:REQUEST_POST,
		subreddit
	}
	
}
export const RECIEVE_POST="RECIEVE_POST";

export function recieve_post(subreddit,json){
	return{
		type:RECIEVE_POST,
		subreddit,
		posts:json.data.children.map(childs=>childs.data),
		recievedAt:Date.now()
			}
}

function fetchPosts(subreddit){
	
	return dispatch =>{
		dispatch(request_post(subreddit));
		
		return fetch(`http://www.reddit.com/r/${subreddit}.json`)
		       .then(response=>response.json())
			   .then(json=>
			   dispatch(recieve_post(subreddit,json)));
			   
		
		
	}
	
}
function shouldFetchPosts(state,subreddit){
	const posts=state.postReducers[subreddit];
	if(!posts){
		return true;
	}
	else if (posts.isFetching){
		return false;
	}
	else{
		return posts.didInvalidate;
	}
	
}
export function fetchpostifNeeded(subreddit){
	return (dispatch,getState)=>{
		
		if(shouldFetchPosts(getState(),subreddit))
		{
			
		return dispatch(fetchPosts(subreddit));	
		}
	}
}
