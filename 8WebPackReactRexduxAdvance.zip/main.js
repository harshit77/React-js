import {createStore,applyMiddleware} from 'redux';
import rootReducer from './reducers/reducers';
import thunkMiddleware  from 'redux-thunk';
import createLogger from 'redux-logger';
import React from 'react';
import ReactDOM from 'react-dom';
import {Provider} from 'react-redux';
import {select_subreddit,fetchPosts} from './actions/actions';
import AsyncApp from './AsyncApp';
const loggerMiddleware=createLogger();
const store=createStore(rootReducer,
 applyMiddleware(
    thunkMiddleware, // lets us dispatch() functions
    loggerMiddleware // neat middleware that logs actions
  ));
  
ReactDOM.render(<Provider store={store}><AsyncApp /></Provider>,document.getElementById("app"));
