import React from 'react';
import Header from './Header';
import Flexisel from './Flexisel';
import GeneralView from './GeneralView';
import Menus from './Menus';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import injectTapEventPlugin from 'react-tap-event-plugin';
injectTapEventPlugin();
export default class App extends React.Component{
	render(){return (
    <div>
	<MuiThemeProvider>
	<Header/>
	</MuiThemeProvider>
	<MuiThemeProvider>
	<GeneralView/>
	</MuiThemeProvider>
	
<MuiThemeProvider>
{this.props.children}
</MuiThemeProvider>
<MuiThemeProvider>
<Flexisel/>
</MuiThemeProvider>
    </div>
  )}
  
}